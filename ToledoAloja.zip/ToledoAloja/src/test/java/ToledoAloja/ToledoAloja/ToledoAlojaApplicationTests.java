package ToledoAloja.ToledoAloja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToledoAlojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
